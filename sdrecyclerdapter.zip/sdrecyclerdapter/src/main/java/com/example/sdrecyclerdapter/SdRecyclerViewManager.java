package com.example.sdrecyclerdapter;

import android.view.View;
import android.view.ViewGroup;

/**
 * Created by sahil gupta on 23/11/18.
 */
public interface SdRecyclerViewManager< T, V extends View > {

	V createView( final ViewGroup iParent );

	void bindData( T data, V v );

	void onClick(T data,V v, int position);
}
