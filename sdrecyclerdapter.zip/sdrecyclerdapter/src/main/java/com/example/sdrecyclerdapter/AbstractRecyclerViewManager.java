package com.example.sdrecyclerdapter;

import android.view.View;

/**
 * Created by sahil gupta on 26/11/18.
 */
public abstract class AbstractRecyclerViewManager< T, V extends View > implements SdRecyclerViewManager< T, V > {

	@Override
	public void onClick( final T data, final V iV, final int position ) {

	}
}
