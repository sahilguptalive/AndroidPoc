package com.example.sdrecyclerdapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by sahil gupta on 23/11/18.
 */
public final class SdRecyclerAdapter extends RecyclerView.Adapter< SdRecyclerViewHolder > {

	private final SparseArray< SdRecyclerViewManager > mViewTypeToViewManagerMap = new SparseArray<>();
	private final HashMap< Object, Integer > mModelClassToViewTypeMap = new HashMap<>();
	private AtomicInteger mViewTypeCount = new AtomicInteger( 0 );

	private final List< Object > mData = new ArrayList<>();

	public static SdRecyclerAdapter newInstance() {

		return new SdRecyclerAdapter();
	}

	@NonNull
	@Override
	public SdRecyclerViewHolder onCreateViewHolder( ViewGroup parent, int viewType ) {

		final SdRecyclerViewManager sdRecyclerViewManager = mViewTypeToViewManagerMap.get( viewType );
		final View view = sdRecyclerViewManager.createView( parent );
		return new SdRecyclerViewHolder( sdRecyclerViewManager == null ? new View( parent.getContext() ) : view );
	}

	@Override
	public int getItemViewType( final int position ) {

		final Object data = getData( position );
		final Integer viewTypeUsingClass = mModelClassToViewTypeMap.get( data.getClass() );
		if ( viewTypeUsingClass != null ) {
			return viewTypeUsingClass;
		}
		final Integer viewTypeUsingRuntimeDataInterface = mModelClassToViewTypeMap.get( data instanceof RuntimeData ? ( ( ( RuntimeData ) data ).getItemType() ) : null );
		return viewTypeUsingRuntimeDataInterface == null ? 0 : viewTypeUsingRuntimeDataInterface;
	}

	@SuppressWarnings( "unchecked" )
	@Override
	public void onBindViewHolder( @NonNull final SdRecyclerViewHolder iSdRecyclerViewHolder, int position ) {

		final SdRecyclerViewManager sdRecyclerViewManager = mViewTypeToViewManagerMap.get( getItemViewType( position ) );
		if ( sdRecyclerViewManager == null ) {
			return;
		}
		addClickListener( position, iSdRecyclerViewHolder, sdRecyclerViewManager );
		sdRecyclerViewManager.bindData( getData( position ), iSdRecyclerViewHolder.itemView );
	}

	private Object getData( final int position ) {

		return mData.get( position );
	}

	@Override
	public int getItemCount() {

		return mData.size();
	}

	public < T > void registerViewType( @NonNull Class< T > dataModel, @NonNull SdRecyclerViewManager< T, ? extends View > viewManager ) {

		final int newViewTypeCount = mViewTypeCount.incrementAndGet();
		mModelClassToViewTypeMap.put( dataModel, newViewTypeCount );
		mViewTypeToViewManagerMap.put( newViewTypeCount, viewManager );
	}

	public < T > void unregisterViewType( @NonNull Class< T > dataModel ) {

		if ( mModelClassToViewTypeMap.get( dataModel ) == null ) {
			return;
		}
		mViewTypeToViewManagerMap.remove( mModelClassToViewTypeMap.get( dataModel ) );
		mModelClassToViewTypeMap.remove( dataModel );
	}

	/**
	 * This method must be used for objects which implement {@link RuntimeData}
	 *
	 * @param viewType
	 * @param viewManager
	 * @param <T>
	 */
	public < T extends RuntimeData > void registerViewType( int viewType, SdRecyclerViewManager< T, ? extends View > viewManager ) {

		final int newViewTypeCount = mViewTypeCount.incrementAndGet();
		mModelClassToViewTypeMap.put( viewType, newViewTypeCount );
		mViewTypeToViewManagerMap.put( newViewTypeCount, viewManager );
	}

	public < T > void unregisterViewType( int viewType ) {


		if ( mModelClassToViewTypeMap.get( viewType ) == null ) {
			return;
		}
		mViewTypeToViewManagerMap.remove( mModelClassToViewTypeMap.get( viewType ) );
		mModelClassToViewTypeMap.remove( viewType );
	}

	public void setData( List< Object > data ) {

		mData.addAll( data );
	}

	private void addClickListener( final int iPosition, final SdRecyclerViewHolder iSdRecyclerViewHolder, final SdRecyclerViewManager iSdRecyclerViewManager ) {

		iSdRecyclerViewHolder.itemView.setOnClickListener( new View.OnClickListener() {

			@Override
			public void onClick( final View v ) {

				iSdRecyclerViewManager.onClick( mData.get( iPosition ), v, iPosition );
			}
		} );

	}
}
