package com.example.sdrecyclerdapter;

/**
 * Created by sahil gupta on 23/11/18.
 */
class ScratchCard {

	public String getMaxDiscount() {

		return maxDiscount;
	}

	public String maxDiscount;
}
