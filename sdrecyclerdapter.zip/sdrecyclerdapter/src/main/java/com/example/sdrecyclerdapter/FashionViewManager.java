package com.example.sdrecyclerdapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by sahil gupta on 23/11/18.
 */
class FashionViewManager implements SdRecyclerViewManager<FashionList,android.view.View> {

	@Override
	public View createView( final ViewGroup iParent ) {

		return new RecyclerView( iParent.getContext() );
	}

	@Override
	public void bindData( final FashionList data, final View iView ) {
		((RecyclerView)iView).setAdapter( new SdRecyclerAdapter());

	}

	@Override
	public void onClick( final FashionList data, final View iView, final int position ) {

	}
}
