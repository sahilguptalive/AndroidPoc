package com.example.sdrecyclerdapter;

/**
 * Created by sahil gupta on 23/11/18.
 */
public interface RuntimeData<T> {

	int getItemType();

	T getData();
}
