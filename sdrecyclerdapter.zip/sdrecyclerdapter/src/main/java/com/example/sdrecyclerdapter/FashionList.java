package com.example.sdrecyclerdapter;

/**
 * Created by sahil gupta on 23/11/18.
 */
class FashionList {

}
