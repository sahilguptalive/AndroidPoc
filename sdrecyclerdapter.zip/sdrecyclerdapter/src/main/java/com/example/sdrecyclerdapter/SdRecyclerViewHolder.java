package com.example.sdrecyclerdapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by sahil gupta on 23/11/18.
 */
final class SdRecyclerViewHolder extends RecyclerView.ViewHolder {

	SdRecyclerViewHolder( @NonNull final View itemView ) {

		super( itemView );
	}
}
